function [Ie]=integrale(fem,ne)

% Calcul de l integrale de la fonction (Ie) sur un element (ne)

% Fonction appellee
% -----------------
% polynomes_T3 :
% Calcul des polynomes sur element triangulaire
% et calcul du determinant du Jacobien

Ie  = 0.;

% ne : numero de l element
% recuperer les poids et abscisses en fonction du type d elements
% polynomes de Lagrange associes a ses noeuds ainsi que leurs
% gradients
    
% chargement des polynomes de Lagrange pour triangles a 3 noeuds
[gauss]=polynomes_T3(fem,ne);

e=fem.elt(ne);
NBN=e.NBN;

NPI  =gauss.NPI;   % nombre de points de Gauss
alpha=gauss.alpha; % alpha(ie, k) ie in [I, NBN] et k in [1, NPI]
detJ =gauss.detJ;  % detJ(k)
pds  =gauss.pds;   % pds(k)

% calcul de l integrale sur 1 element
% A COMPLETER

for k=1:NPI
   
    Qk=0; % interpolee au point k
    for ie=1:NBN % I, II, III
        iglobal = e.ind(ie);  % passage local -> global
        Qie = fem.sol(iglobal);  % fem.sol valeur aux noeuds globaux du maillage      
        Qk = Qk + Qie*alpha(ie, k); % accumulation
    end
        
    Ie = Ie + Qk *detJ(k)*pds(k); % accumulation
    
end

end









