function [Ie, Se]=integrale(fem,ne)

% Calcul de l integrale de la fonction (Ie) sur un element (ne)

% Fonction appelee
% -----------------
% polynomes_T3 :
% Calcul des polynomes sur element triangulaire
% et calcul du determinant du Jacobien

Ie = 0.;
Se = 0.;
% ne : numero de l element
% recuperer les poids et abscisses en fonction du type d elements
% polynomes de Lagrange associes a ses noeuds ainsi que leurs
% gradients
    
% chargement des polynomes de Lagrange pour triangles a 3 noeuds
[gauss]=polynomes_T3(fem,ne);

e=fem.elt(ne);
NBN=e.NBN;

% calcul de l integrale sur 1 element
% A COMPLETER

NPI  = gauss.NPI; 	% nombre de points de Gauss 
detJ = gauss.detJ;	% tableau = valeur de detJ(k) k numero du point de Gauss 
pds  = gauss.pds;	% tableau = valeur de w(k)
alpha= gauss.alpha;	% matrice = gauss.alpha(ie, k) 
                    % ie dans {I, II, III}, k dans [1, gauss.NPI]

for k=1:NPI
    
    Qk = 0; % interpolee au point de Gauss k
    for ie=1:NBN
        iglobal = e.ind(ie);    % passage local -> global
        Qie = fem.sol(iglobal); % 
        Qk = Qk + Qie*alpha(ie, k); %  QI, QII et QIII interviennent
    end
    
    Ie = Ie + Qk * detJ(k)*pds(k);
    Se = Se +      detJ(k)*pds(k);
end

end









