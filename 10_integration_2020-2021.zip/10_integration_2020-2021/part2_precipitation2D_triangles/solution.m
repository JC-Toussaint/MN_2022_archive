function [I]=solution(fem)

I = 0.0;  % accumulateur mis a zero
S = 0.0;

NE=fem.NE;
for ne = 1:NE % boucle sur tous les elements
    
    % Calcul de l'integrale elementaire et de la surface
    [Ie, Se]=integrale(fem,ne);
    
    % Accumulation
    I = I + Ie; % Calcul de la precipitation
    S = S + Se;
end

I= I/S;
end

