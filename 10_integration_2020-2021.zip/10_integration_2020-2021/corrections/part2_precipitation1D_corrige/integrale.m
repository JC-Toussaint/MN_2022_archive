function [Ie]=integrale(fem,ne)
% Calcul de l integrale de la fonction Ie sur l'element ne
%
% Fonction appellee
% -----------------
% polynomes_L2 :
% Calcul des polynomes sur element lineaire
% et calcul du determinant du Jacobien

Ie = 0.;

% ne : numero de l element
% recuperer les poids et abscisses en fonction du type d elements
% polynomes de Lagrange associes a ses noeuds ainsi que leurs
% gradients

% chargement des polynomes de Lagrange pour le segment a 2 noeuds
[gauss]=polynomes_L2(fem,ne);
 

NPI=gauss.NPI;
NBN=fem.elt(ne).NBN;

% calcul de l integrale sur 1'element
for npi = 1:NPI

    % calcul de f(x) aux points d integration par interpolation
    Qe_npi = 0.;
    for ie = 1:NBN
        e=fem.elt(ne);
        iglobal=e.ind(ie);
        Qe_npi = Qe_npi + gauss.alpha(ie,npi)*fem.sol(iglobal);
    end
    
    Ie = Ie + gauss.pds(npi)*gauss.detJ(npi)*Qe_npi;
end
