% Integration par la methode de Gauss 2 points
% Principe : pour N=1 Integrale=Somme_sur_i(Poids(i)*f(Abscisses(i))) i=1,2
% Dans un element de reference [-1;1] :
%          Poids = ( 1 ; 1 )
%          Abscisses = ( -1/sqrt(3) ; +1/sqrt(3) )

function I=gauss2(f,a,b,N)
dx=(b-a)/N;
x0=linspace(a,b-dx,N)+dx/2;
x1=x0-dx/2*1/sqrt(3);
x2=x0+dx/2*1/sqrt(3);

I=dx/2*sum(f(x1)+f(x2));
