% Integration par la methode de Gauss 2 points
% Principe : pour N=1 Integrale=Somme_sur_i(Poids(i)*f(Abscisses(i))) i=1,3
% Dans un element de reference [-1;1] :
%          Poids = (5/9 ; 8/9 ; 5/9)
%          Abscisses = (-sqrt(3/5) ; 0 ; sqrt(3/5))

function I=gauss3(f,a,b,N)
dx=(b-a)/N;
x1=linspace(a,b-dx,N)+dx/2; %point milieu
x0=x1-dx/2*sqrt(3/5);     %point gauche
x2=x1+dx/2*sqrt(3/5);     %point droit

I=dx/2*sum(5/9*f(x0)+8/9*f(x1)+5/9*f(x2));
