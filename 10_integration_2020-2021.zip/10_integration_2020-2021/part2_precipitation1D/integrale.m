function [Ie]=integrale(fem,ne)
% Calcul de l integrale de la fonction Ie sur l'element ne
%
% Fonction appellee
% -----------------
% polynomes_L2 :
% Calcul des polynomes sur element lineaire
% et calcul du determinant du Jacobien

Ie = 0.;

% ne : numero de l element
% recuperer les poids et abscisses en fonction du type d elements
% polynomes de Lagrange associes a ses noeuds ainsi que leurs
% gradients

% chargement des polynomes de Lagrange pour le segment a 2 noeuds
[gauss]=polynomes_L2(fem,ne);  
 
e=fem.elt(ne);
NBN=e.NBN;

NPI=gauss.NPI;
alpha = gauss.alpha; % alpha(ie, k) ie in [I, NBN] et k in [1, NPI]
detJ  = gauss.detJ;  % detJ(k)
pds   = gauss.pds;   % pds(k) = w(k)

% A COMPLETER %
Ie=0;
for k=1:NPI
    
    Qk=0;  % interpolee au point k
    for ie=1:NBN % I puis II
        iglobal=e.ind(ie); % passage local --> global
        Qie =fem.sol(iglobal);   
        Qk = Qk + Qie * alpha(ie, k);  % Q_I alpha(I, k) + Q_II alpha(II, k)
    end
    
    Ie = Ie + Qk * detJ(k)*pds(k);
end

