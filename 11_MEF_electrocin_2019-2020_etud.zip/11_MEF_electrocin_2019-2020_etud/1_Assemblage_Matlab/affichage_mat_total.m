function affichage_mat_total(Mat)

NP=length(Mat);

h=figure;
clf;
set(h, 'Position',[550 350 800 400]);

   axis([0 NP -NP 0]);
   grid on;
   
   for i=1:NP
        for j=1:NP
                s=Mat(i,j);
                text(i-0.5,-(j-0.5),s,'Fontsize',8,'HorizontalAlignment','center');
        end
   end
end
