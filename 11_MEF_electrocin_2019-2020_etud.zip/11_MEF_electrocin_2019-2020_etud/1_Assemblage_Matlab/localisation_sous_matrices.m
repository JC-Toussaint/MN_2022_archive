function [AE]=localisation_sous_matrices(fem)

% fem.NP : nb de neouds
% fem.NE : nb d'elements
AE=zeros(fem.NP, fem.NP, fem.NE);

for ne=1:fem.NE 
    e=fem.elt(ne);  % element courant
    NBN=e.NBN;      % nombre de noeuds de l'element courant

	for ie=1:NBN
        %numero global du ie(eme) noeud de l'element e 
        i=e.ind(ie);    
	
        for je=1:NBN
            %numero global du je(eme) noeud de l'element e 
            j = e.ind(je);  
            
            %On met a jour la matrice A
            AE(i, j, ne) = ne;
        end;
	end;
end;

