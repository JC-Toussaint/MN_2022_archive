function  [fem]=echange_noeuds(n1,n2,fem)

if (n1<=0) | (n1>fem.NP) 
   return
end;

if (n2<=0) | (n2>fem.NP) 
   return
end;

% echange des coordonnees des noeuds 
noeud1=fem.noeud(n1);
noeud2=fem.noeud(n2);
fem.noeud(n1)=noeud2;
fem.noeud(n2)=noeud1;

% echange des noeuds dans la table de connectivite
for ne=1:fem.NE 
    e=fem.elt(ne);
    for nbn=1:e.NBN
        switch (e.ind(nbn))
            case n1
                e.ind(nbn)=n2;
            case n2
                e.ind(nbn)=n1;
        end;          
    end;
    fem.elt(ne)=e;  
end;    

% echange des valeurs aux noeuds
% sol1=fem.sol(n1);
% sol2=fem.sol(n2);
% fem.sol(n1)=sol2;
% fem.sol(n2)=sol1;

