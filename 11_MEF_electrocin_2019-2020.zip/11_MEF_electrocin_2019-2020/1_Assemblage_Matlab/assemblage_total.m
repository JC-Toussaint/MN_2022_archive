function [A]=assemblage_total(AE,fem)

    for i=1:fem.NP
        for j=1:fem.NP
            if (AE(i,j,1)==0)
                s='-';
            else
                s=int2str(AE(i,j,1));
            end;
            for k=2:fem.NE
                if (AE(i,j,k)==0)
                s1='-';
                else
                s1=int2str(AE(i,j,k));
            end;
   	            s=strcat(s,s1);
            end;
            A(i,j)=cellstr(s);
        end;
    end;

