clear all;
close all;

% liste de tous les fichiers de maillage
files=dir('*.dat');
text={files(:).name}; % stockage dans un tableau

% choix dans une liste
[rg, ok] = listdlg('PromptString','choisir un maillage',...
                   'SelectionMode','single',...
                   'ListString', text,...
                   'listSize',[400 80]);
% nom du maillage selectionne
nom=files(rg).name;       

% lecture maillage + valeurs aux noeuds
[fem, err]=lecture_maillage(nom);

while 1 
	
	% affichage maillage avec numerotation des noeuds et des elements
	affichage_maillage(fem);
     
     %localisation dans la matrice globale des elements des sous-matrices
	AE=localisation_sous_matrices(fem);
	
	% assemblage
	A=assemblage_total(AE, fem);
	
	% affichage de la matrice totale
	affichage_mat_total(A);
	
	% echange de deux noeuds
    prompt = {'numero du 1er noeud (0=stop):','numero du 2eme noeud :'};
    titre  = 'echange de noeuds';
    nlignes = 1;
    def     = {'1','2'};
    rep  = inputdlg(prompt,titre,nlignes,def);
	n1=str2double(rep(1));
	n2=str2double(rep(2));
    
    if (n1==0) || (n2==0) 
        close all;
        break;
    end    
	fem=echange_noeuds(n1, n2, fem);

end


