% [A,B]=assemblage(fem ,ne, AE, BE, A, B) 
% Accumulation des matrices elementaires AE et BE dans les
% matrices globales A et B
% Entree/
% structure fem et ne numero de l'element a traiter
% AE et BE matrices elementaires associees a l'element ne
% Entree et Sortie
% A et B matrices globales

function [A,B]=assemblage(fem ,ne, AE, BE, A, B)  

% traitement de l'element e=fem.elt(ne)
e=fem.elt(ne);
NBN=e.NBN;

% A COMPLETER
