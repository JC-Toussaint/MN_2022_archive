% factorisation PLU d'une matrice A
% A=P*L*U

function [P, L, U]=PLU(A)

Epsilon=1.0e-6;
n=size(A, 1); % nb de lignes de A
In=eye(n , n);
PL=In;
P =In;

Epsilon=1.0e-6;
for k=1:n-1
    Pk=In;
    i=find_pivot(A, k);
    
    Pk([i, k], :)=Pk([k, i], :);
    A ([i, k], :)=A ([k, i], :);
    
    if (abs(A(k,k))<Epsilon)
        error('akk trop petit !');
    end
    invLk=In;
    for i=k+1:n
        invLk(i, k)=-A(i, k)/A(k, k);
    end
    
    A=invLk*A;
    Lk=-invLk+2*In;
    PLk=Pk*Lk;
    PL=PL*PLk;
    P=P*Pk;
end

U=A;
invP=P';
L=invP*PL;
end

function idx=find_pivot(A, k)
[~, idx]=max(abs(A(k:end, k)));
idx=idx+k-1;
end






