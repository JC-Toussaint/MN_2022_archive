function [L,U] = LUsp(A)

% Factorisation LU SANS PIVOT de la matrice A

n = size(A,1) ;
% Initialisation de la matrice L
Id=eye(n);
L=Id;
ier = 0 ;
Epsilon=1.0e-6;
for k = 1:n-1
    if (abs(A(k,k))<Epsilon)
        error('akk trop petit !');
    end
    
    % Construction de la matrice d’elimination
    inv_Lk=Id;
    for i = k+1:n
        inv_Lk(i,k)=-A(i,k)/A(k,k);
    end
    
    % Construction de la matrice A(k+1) a partir de A(k)
    A=inv_Lk*A;
    
    Lk=-inv_Lk+2*Id; % Inverse de la matrice d’elimination
    L=L*Lk;
    
    % A COMPLETER
    
end
% La derniere matrice A(k+1) est la matrice triangulaire superieure
U=A;
end






