function x = solve(L, U, b)

% Resolution d'un systeme lineaire suite a la factorisation LU de sa matrice
% par Descente-Remontee 
%
% ENTREE
%   L : Matrice triangulaire inferieure (sortie de LUsp)
%   U : Matrice triangulaire superieure (sortie de LUsp)
%   b    : second membre du systeme
% 
% SORTIE 
%   x : solution du systeme
%
% APPEL 
%   x=solve(L,U,b) : renvoie dans x la solution de Ax=b ou L,U sont les 
%   matrices triangulaires inf et sup de la matrice A 
% 
% LU x = b     L y = b
n = size(L,1) ;

%
% Resolution par descente remontee LUx=b
%
% Descente Ly=b
y = zeros(n, 1);
y(1) = b(1) / L(1, 1);
for k=2:n
    l=1:k-1;
    v = L(k, l)*y(l);
    y(k) = (b(k)-v)/L(k,k);
end

% A COMPLETER

% Remontee Ux=y
x = zeros(n, 1);
x(n) = y(n) / U(n,n);
for k=n-1:-1:1
    l=k+1:n;
    v = U(k,l)*x(l);
    x(k) = (y(k)-v)/U(k,k);
end

% A COMPLETER

end


