function [Ie]=integrale(fem,ne)

% Calcul de l integrale de la fonction (Ie) sur un element (ne)

% Fonction appellee
% -----------------
% polynomes_Q4 :
% Calcul des polynomes sur element triangulaire
% et calcul du determinant du Jacobien

Ie  = 0.;

% ne : numero de l element
% recuperer les poids et abscisses en fonction du type d elements
% polynomes de Lagrange associes a ses noeuds ainsi que leurs
% gradients
    
% chargement des polynomes de Lagrange pour triangles a 3 noeuds
[gauss]=polynomes_Q4(fem,ne);

NPI=gauss.NPI;
NBN=fem.elt(ne).NBN;
alpha=gauss.alpha;

% calcul de l integrale sur 1 element
for npi = 1:NPI

    % calcul de f(x,y) aux points d integration par interpolation
    Qe_npi = 0.;
    for ie = 1:NBN
        iglobal=fem.elt(ne).ind(ie);
        Qe_npi = Qe_npi + alpha(ie,npi)*fem.sol(iglobal);
    end
    
    Ie = Ie + gauss.pds(npi)*gauss.detJ(npi)*Qe_npi;
end
