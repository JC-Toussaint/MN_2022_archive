function [Ie]=integrale(fem, ne)
% Calcul de l integrale de la fonction Ie sur l'element ne
%
% Fonction appelee
% -----------------
% polynomes_L2 :
% Calcul des polynomes sur element lineaire
% et calcul du determinant du Jacobien

Ie = 0.;

% ne : numero de l element
% recuperer les poids et abscisses en fonction du type d elements
% polynomes de Lagrange associes a ses noeuds ainsi que leurs
% gradients

% chargement des polynomes de Lagrange pour le segment a 2 noeuds
[gauss]=polynomes_L2(fem,ne);
 
NPI=gauss.NPI;
NBN=fem.elt(ne).NBN;

detJ  = gauss.detJ;  % detJ(k)
pds   = gauss.pds;   % pds(k)
alpha = gauss.alpha; % alpha(ie, k)

% A COMPLETER %
e=fem.elt(ne);
Ie=0;
for k=1:NPI
    
    Qk=0; % interpolee au point de Gauss k
    for ie=1:NBN % I puis II
        iglobal=e.ind(ie); % passage local --> global
        Qie =fem.sol(iglobal);
        Qk = Qk + Qie*alpha(ie, k); % Qie = QI puis QII
    end
    
    % integration de l'interpolee
    Ie = Ie + Qk * pds(k)*detJ(k);
end

