function [gauss]=polynomes_Q4(fem,ne)
% Calcul des polynomes aux points d'integration
% Polynomes dans un element quadrilatere a l ordre 1
% Calcul du determinant de la matrice Jacobienne aux npi
% points d integration --> gauss.detJ

% Nombre de noeuds dans l'element e
NBN=fem.elt(ne).NBN;

% Nombre de points d integration
NPI=1;

% poids et abscisses de Gauss
switch NPI
case 1
    % Coordonnees du point d integration
	u = [0.0] ;
	v = [0.0] ;
    % poids de Gauss associé
    pds = [4.0] ;
case 4
    % Coordonnees des 4 points d integration
    r=1/sqrt(3);
	u =[-r +r +r -r];
	v =[-r -r +r +r];
    % Poids de Gauss
	pds = [1.0 1.0 1.0 1.0];
end
    
%calcul des polynomes de Lagrange et de leurs gradients 
% aux points d integration
for npi=1:NPI
   % Polynomes aux noeuds I,II,III et IV
   alpha(1,npi)=(1-u(npi))*(1-v(npi))/4.;
   alpha(2,npi)=(1+u(npi))*(1-v(npi))/4.;
   alpha(3,npi)=(1+u(npi))*(1+v(npi))/4.;
   alpha(4,npi)=(1-u(npi))*(1+v(npi))/4.; 
end;

dalpha_du=zeros(NBN,NPI);
dalpha_dv=zeros(NBN,NPI);

% derivees polynomes de Lagrange P1 dans l'element de reference
for npi=1:NPI
    % dalpha_du(ie, npi) derivee par rapport a u 
    % du polynome de Lagrange calculee au point de Gauss npi
   dalpha_du(1,npi)=-(1-v(npi))/4.;
   dalpha_du(2,npi)=(1-v(npi))/4.;
   dalpha_du(3,npi)=(1+v(npi))/4.;
   dalpha_du(4,npi)=-(1+v(npi))/4.;

    % dalpha_dv(ie, npi) derivee par rapport a v 
    % du polynome de Lagrange calculee au point de Gauss npi
   dalpha_dv(1,npi)=-(1-u(npi))/4.;
   dalpha_dv(2,npi)=-(1+u(npi))/4.;
   dalpha_dv(3,npi)=(1+u(npi))/4.;
   dalpha_dv(4,npi)=(1-u(npi))/4.;
end;

%=======================================================================
%Calcul du determinant de la matrice Jacobienne aux points d integration
%Stockage dans la structure gauss.detJ
%=======================================================================

% J : matrice Jacobienne [J]
J=zeros(2,2,NPI);
% detJ : determinant de [J]
detJ=zeros(NPI,1);

for ie=1:NBN
    iglobal=fem.elt(ne).ind(ie);
    xp(ie)  = fem.noeud(iglobal).x;
    yp(ie)  = fem.noeud(iglobal).y;
end

for npi=1:NPI
    % nombre de noeuds dans l element ne
    NBN=fem.elt(ne).NBN;
    dx_du = 0.;
    dx_dv = 0.;

    dy_dv = 0.;
    dy_du= 0.;

    for ie = 1:NBN
        dx_du = dx_du + dalpha_du(ie,npi)*xp(ie);
        dx_dv = dx_dv + dalpha_dv(ie,npi)*xp(ie);

        dy_dv = dy_dv + dalpha_dv(ie,npi)*yp(ie);	 
        dy_du = dy_du + dalpha_du(ie,npi)*yp(ie);	 
    end
    
    % Matrice Jacobienne transposee
    J=[dx_du dy_du;
       dx_dv dy_dv];

    % Calcul du determinant de la matrice Jacobienne aux npi
    detJ(npi)=det(J);    

    if (detJ(npi)~=0) 
       invJ=inv(J);
    else
       error('Matrice Jacobienne non inversible!');
    end;
    
end;

gauss.NPI=NPI; 		% nombre de points de Gauss 
gauss.detJ=detJ;	% tableau = valeur de detJ(k) k numero du point de Gauss 
gauss.pds=pds;		% tableau = valeur de w(k)
gauss.alpha=alpha;	% matrice = gauss.alpha(ie, k) ie dans {I, II}, k dans [1, gauss.NPI]

