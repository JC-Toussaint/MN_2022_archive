function [Ie]=integrale(fem,ne)

% Calcul de l integrale de la fonction (Ie) sur un element (ne)

% Fonction appellee
% -----------------
% polynomes_Q4 :
% Calcul des polynomes sur element quadrilatere
% et calcul du determinant du Jacobien

Ie  = 0.;

% ne : numero de l element
% recuperer les poids et abscisses en fonction du type d elements
% polynomes de Lagrange associes a ses noeuds ainsi que leurs
% gradients
    
% chargement des polynomes de Lagrange pour quadrangle a 4 noeuds
[gauss]=polynomes_Q4(fem,ne);

NPI=gauss.NPI;
alpha=gauss.alpha; % alpha(ie, k)
detJ =gauss.detJ;  % detJ(k)
pds =gauss.pds;    % pds(k)

e=fem.elt(ne);
NBN=fem.elt(ne).NBN;


% calcul de l integrale sur 1 element
for k = 1:NPI

    % calcul de l'interpolee aux points d integration 
    Qk = 0.;
    for ie = 1:NBN
        iglobal=e.ind(ie);
        Qie = fem.sol(iglobal);
        Qk = Qk + alpha(ie, k)*Qie;
    end
    
    Ie = Ie + pds(k)*detJ(k) * Qk;
end
