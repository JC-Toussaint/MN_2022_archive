% Integration numerique par Rectangle, Trapeze, Simpson et Gauss
%=======================================================================
%			Saisie des donnees utilisateur
%=======================================================================
clc
close all
clear all

prompt = {'Fonction a integrer','a','b','nb elements'};
dlg_title = 'Donnees pour l''integration';
num_lines= 1;
def     = {'4./(1.+x.^2)','0','1','1'};
valeur  = inputdlg(prompt,dlg_title,num_lines,def);

f = inline(cell2mat(valeur(1)));
a = str2double(valeur(2));
b = str2double(valeur(3));
n = str2double(valeur(4));

%=======================================================================
%			Tracer de la courbe sur l'intervalle [a:b]
%=======================================================================
x=a:(b-a)/100:b;
y=feval(f,x);
plot(x,y);
title('Courbe a integrer');
xlabel('x');
ylabel('y');
grid on;
%=======================================================================
%			Calcul et affichage des int�grales approch�es
%=======================================================================
N=6;
t=zeros(N+1, 8);

for p=0:N
    s=['x.^' num2str(p)]
    f = inline(s);
    
    i=p+1;
    t(i, 1)=p;
    t(i, 2)=1/(p+1);
    
    Irect = rectangles(f,a,b,n);
    Itrap = trapezes(f,a,b,n);
    Isimp = simpson(f,a,b,n);
    Igauss1 = gauss1(f,a,b,n);
    Igauss2 = gauss2(f,a,b,n);
    Igauss3 = gauss3(f,a,b,n);
    
    t(i, 3) = Irect;
    t(i, 4) = Itrap;
    t(i, 5) = Isimp;
    t(i, 6) = Igauss1;
    t(i, 7) = Igauss2;
    t(i, 8) = Igauss3;
    
end;








