% Integration par la methode des trapezes
% Principe pour N=1 : Integrale=(b-a)/2*(f(a)+f(b))

function I=trapezes(f,a,b,N)

dx=(b-a)/N;
x0=linspace(a,b-dx,N); 
x1=x0+dx;
I=dx/2.*sum(f(x0)+f(x1));
