% Integration par la methode des rectangles
% Principe pour n=1 : Integrale=(b-a)*f((a+b)/2)

function I=rectangles(f,a,b,n)
inter=(b-a)/n;
x=a+inter/2+(b-a)/n*[0:n-1];
I=inter*sum(feval(f,x));
