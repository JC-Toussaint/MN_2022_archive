% Integration numerique par Rectangle, Trapeze, Simpson et Gauss
%=======================================================================
%			Saisie des donnees utilisateur
%=======================================================================

clc
close all
clear all

prompt = {'Fonction a integrer','a','b','nb elements'};
dlg_title = 'Donnees pour l''integration';
num_lines= 1;
def     = {'4./(1.+x.^2)','0','1','1'};
valeur  = inputdlg(prompt,dlg_title,num_lines,def);

f = inline(cell2mat(valeur(1)));
a = str2double(valeur(2));
b = str2double(valeur(3));
n = str2double(valeur(4));

%=======================================================================
%			Tracer de la courbe sur l'intervalle [a:b]
%=======================================================================
x=a:(b-a)/100:b;
y=feval(f,x);
plot(x,y);
title('fonction a integrer');
xlabel('x');
ylabel('y');
grid on;
%=======================================================================
%			Calcul et affichage des integrales approchees
%=======================================================================
%Irect = rectangles(f,a,b,n)
%Itrap = trapezes(f,a,b,n)
%Isimp = simpson(f,a,b,n)
format long
Igauss1 = gauss1(f,a,b,n)-pi
%Igauss2 = gauss2(f,a,b,n)
%Igauss3 = gauss3(f,a,b,n)
