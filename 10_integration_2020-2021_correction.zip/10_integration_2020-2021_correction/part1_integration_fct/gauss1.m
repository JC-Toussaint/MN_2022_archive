% Integration par la methode de Gauss 1 point
% Principe : pour N=1 Integrale=Poids(1)*f(Abscisses(1))
% Dans un element de reference [-1;1] :
%          Poids = ( 2 )
%          Abscisses = ( 0 )

function I=gauss1(f,a,b,N)
dx=(b-a)/N;
x0=linspace(a,b-dx,N)+dx/2; 
I=dx*sum(f(x0));
