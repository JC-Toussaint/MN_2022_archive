% Integration par la methode de Simpson
% Principe pour N=1 : Integrale=(b-a)/6*(f(a)+4*f((a+b)/2)+f(b))

function I=simpson(f,a,b,N)
dx=(b-a)/N;
x0=linspace(a,b-dx,N); 
x1=x0+dx/2;
x2=x0+dx;

I=dx/6.*sum(f(x0)+4*f(x1)+f(x2));
