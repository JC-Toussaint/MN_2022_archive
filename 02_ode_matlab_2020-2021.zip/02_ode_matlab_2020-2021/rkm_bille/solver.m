function solver
close all % ferme toutes les fenetres
clear % efface les variables
[T,Y] = rkm(@equadif_bille,[0 12 0.1],[1 0 pi/2 0]);

hold on

plot(T,Y(:,1), 'color', [1 0 0]);
plot(T,Y(:,2), 'color', [0 1 0]);
plot(T,Y(:,3), 'color', [0 0 1]);
plot(T,Y(:,4), 'color', [0 0 0]);

save 'mydata.mat'

[T,Y] = ode45(@equadif_bille,[0 12],[1 0 pi/2 0]);
plot(T,Y(:,1), 'color', [1 0 0]);
plot(T,Y(:,2), 'color', [0 1 0]);
plot(T,Y(:,3), 'color', [0 0 1]);
plot(T,Y(:,4), 'color', [0 0 0]);

figure
plot(Y(:,1),Y(:,2), 'color', [0 0 0]);


