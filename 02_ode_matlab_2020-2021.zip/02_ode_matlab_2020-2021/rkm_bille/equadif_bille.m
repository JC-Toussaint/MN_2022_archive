function dy=equadif_bille(t,y)

dy=zeros(1, 4); % vecteur ligne

k=6.;
m=0.1;
L=1.;
g=9.81;

% changement de notation pour visibilite
r=y(1);
v=y(2);
theta=y(3);
omega=y(4);

if (r>0)
    dr_dt=v;
    dv_dt=r*omega*omega-(k/m)*(r-L)+g*cos(theta);
    dtheta_dt=omega;
    domega_dt=(-g*sin(theta)-2*v*omega)/r;

    dy(1)=dr_dt;;
    dy(2)=dv_dt;
    dy(3)=dtheta_dt;
    dy(4)=domega_dt;
else
    disp('r<0');
    return;
end;
