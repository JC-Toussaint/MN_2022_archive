function solver_rk4
clc
close all % ferme fenetres graphiques
clear % efface les variables

[T,Y] = rk4(@penduleosc,[0 120 0.01],[1 0 pi/2 0]);

hold on

% changement de notation pour visibilite
r=Y(:, 1);
v=Y(:, 2);
theta=Y(:, 3);
omega=Y(:, 4);

plot(T,r, 'color', [1 0 0]);
plot(T,v, 'color', [0 1 0]);
plot(T,theta, 'color', [0 0 1]);
plot(T,omega, 'color', [0 0 0]);

k=6.;
m=0.1;
L=1.;
g=9.81;

Tm=0.5*m*(v.^2+(r.*omega).^2);
Vm=0.5*k*(r-L).^2-m*g*r.*cos(theta);

figure
plot(T, Tm, 'r');
hold on
plot(T, Vm, 'b');

Etot=Tm+Vm;
plot(T, Etot, 'g');
grid on
min(Etot)
max(Etot)
end

