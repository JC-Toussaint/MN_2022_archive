function solver

hold off
tf=20;
s0=1;   r0=1;
dt=1e-2;

[T,Y] = rkm(@volterra,[0 tf dt],[s0 r0]);

plot(T,Y(:,1),'-',T,Y(:,2),'-.')
figure
plot(Y(:,1),Y(:,2),'r-')
save 'mydata.mat'


function dy = volterra(t,y)
dy = zeros(1, 2);    % vecteur ligne

% parametres
a=3; % frequence de reproduction des sardines sans requin
b=1; % frequence de disparition des sardines en presence des requins
c=1; % frequence de reproduction des requins en presence des sardines
d=2; % frequence de disparition des requins sans sardine

% changement de variable pour garder les notations de l'�quation
s=y(1); % sardines
r=y(2); % requins

% �criture de l'�quation telle quelle
ds_dt = a*s-b*s*r;
dr_dt = c*s*r-d*r;

% changement de variable pour se conformer au vecteur de sortie dy
dy(1)=ds_dt;
dy(2)=dr_dt;
