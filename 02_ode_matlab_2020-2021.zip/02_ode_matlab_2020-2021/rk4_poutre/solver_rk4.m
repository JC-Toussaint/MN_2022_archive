%function solver_rk4
clc
close all
clear all

L=3;

param=[0 L 0.1];

a=0; b=5e-3;
eps=1e-6;

while abs(b-a)>eps
    [X,Y] = rk4(@poutre,param,[0 a]);
    sa=Y(end, 2);

    [X,Y] = rk4(@poutre,param,[0 b]);
    sb=Y(end, 2);

    m=0.5*(a+b);
    [X,Y] = rk4(@poutre,param,[0 m]);
    sm=Y(end, 2);

    if sa*sm <0 
       b=m;
    end;
    if sm*sb <0
       a=m;
    end;

end;
a 
b    


x=X;
y=Y(:,1);
v=Y(:,2);

plot(X, y,'r+-');
figure
plot(X, v,'b+-');

T=5000;
E=1e10;
mu=4.2;
g=9.8;

a=5e-2;
b=10e-2;

I=b*a^3;
mu*g/(2*E*I)
T/(E*I)

N=length(x);
int1=zeros(1, N);
for i=2:N
    xa=x(i-1);    va=v(i-1);
    xb=x(i);      vb=v(i);
    dx=xb-xa;
    int1(i)=int1(i-1)-0.5*mu*g*dx/2*(xa^2*va+xb^2*vb);  
end;

int2=zeros(1, N);
for i=1:N
    int2(i)=(0.5*E*I*(v(i)^2-v(1)^2)-0.5*T*(y(i)^2-y(1)^2));
end;

figure
plot(x, int1, 'r');
hold on
plot(x, int2, 'bo');





