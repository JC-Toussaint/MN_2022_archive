function dU_dx = poutre(x, U)
dU_dx = zeros(1, 2);    % a row vector

% parametres
T=5000;
E=1e10;
mu=4.2;
g=9.8;

a=5e-2;
b=10e-2;

I=b*a^3;


% changement de variable pour garder les notations de l'?quation
y=U(1);
v=U(2);

% ecriture de l'equation telle quelle
dy_dx = v;
dv_dx = (T/(E*I))*y-mu*g/(2*E*I)*x^2;

% changement de variable pour se conformer au vecteur de sortie dy
dU_dx(1)=dy_dx;
dU_dx(2)=dv_dx;

end
