function solver
close all % ferme toutes les fenetres
clear % efface les variables
Y0=[5 -8 6];
[Tm,Ym] = rkm(@lorenz,[0 200 0.1], Y0);

hold on

plot(Tm, Ym(:,1), 'color', [1 0 0]);
plot(Tm, Ym(:,2), 'color', [0 1 0]);
plot(Tm, Ym(:,3), 'color', [0 0 1]);


[T4,Y4] = rk4(@lorenz,[0 200 0.02], Y0);

[T,Y] = ode45(@lorenz,[0 200], Y0);
plot(T, Y(:,1), 'color', [1 0 0]);
plot(T, Y(:,2), 'color', [0 1 0]);
plot(T, Y(:,3), 'color', [0 0 1]);

figure
hold on
plot3(Y(:,1),Y(:,2), Y(:,3), 'color', [0 0 0]);
plot3(Ym(:,1),Ym(:,2), Ym(:,3), '-.', 'color', [1 0 0]);
plot3(Y4(:,1),Y4(:,2), Y4(:,3), '-o', 'color', [0 0 1]);

save 'mydata.mat'



function du=lorenz(t,u)

du=zeros(1, 3); % vecteur ligne

sigma=1;
rho=26.5;
beta=1;

x=u(1);
y=u(2);
z=u(3);

dx_dt=sigma*(y-x);
dy_dt=rho*x-y-x*z;
dz_dt=x*y-beta*z;

du(1)=dx_dt;
du(2)=dy_dt;
du(3)=dz_dt;



