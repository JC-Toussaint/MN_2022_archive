function solver
clc
close all
[T,Y] = rkm(@pendule,[0 12 0.1],[pi/4 0]);
plot(T,Y(:,1),'-',T,Y(:,2),'-.')
hold on
[T,Y] = ode45(@pendule,[0 12],[pi/4 0]);
plot(T,Y(:,1),'-',T,Y(:,2),'-.')
save 'mydata.mat'
grid on

function dy = pendule(t,y)
dy = zeros(1, 2);    % vecteur ligne

% constantes
g=9.81;
L=1;

% changement de variable pour garder les notations de l'�quation
teta =y(1);
omega=y(2);

% �criture de l'�quation telle quelle
dteta_dt  = omega;
domega_dt = -g/L*sin(teta);

% changement de variable pour se conformer au vecteur de sortie dy
dy(1)=dteta_dt;
dy(2)=domega_dt;
