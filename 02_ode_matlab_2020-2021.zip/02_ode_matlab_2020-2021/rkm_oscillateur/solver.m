function solver
hold off
[T,Y] = rkm(@oscil,[0 12 0.1],[1 0]);
plot(T,Y(:,1),'-',T,Y(:,2),'-.')
hold on
[T,Y] = ode45(@oscil,[0 12],[1 0]);
plot(T,Y(:,1),'-',T,Y(:,2),'-.')
save 'mydata.mat'

function dy = oscil(t,y)
dy = zeros(1, 2);    % vecteur ligne

%2eme cas
n=0.2;
p2=1;

% changement de variable pour garder les notations de l'�quation
x=y(1);
v=y(2);

% �criture de l'�quation telle quelle
dx_dt = v;
dv_dt = -p2*x-2*n*v;

% changement de variable pour se conformer au vecteur de sortie dy
dy(1)=dx_dt;
dy(2)=dv_dt;
