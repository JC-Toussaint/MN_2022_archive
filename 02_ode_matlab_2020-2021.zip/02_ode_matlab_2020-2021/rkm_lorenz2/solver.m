function solver
close all % ferme toutes les fenetres
clear % efface les variables

Y0=[5 -8 6];
[T,Y] = rkm(@lorenz,[0 200 0.1], Y0);

eps=1e-5;
Y0=[5+eps -8 6];
[Tp,Yp] = rkm(@lorenz,[0 200 0.1], Y0);

hold on
plot(T,  Y(:,1),  '-',  'color', [0 0 0]);
plot(Tp, Yp(:,1), '-.', 'color', [1 0 0]);

figure
hold on
plot3(Y(:,1),Y(:,2), Y(:,3), 'color', [0 0 0]);
plot3(Yp(:,1),Yp(:,2), Yp(:,3), '-.', 'color', [1 0 0]);

save 'mydata.mat'



function du=lorenz(t,u)

du=zeros(1, 3);

sigma=3;
rho=26.5;
beta=1;

x=u(1);
y=u(2);
z=u(3);

dx_dt=sigma*(y-x);
dy_dt=rho*x-y-x*z;
dz_dt=x*y-beta*z;

du(1)=dx_dt;
du(2)=dy_dt;
du(3)=dz_dt;



