function fdm=init(Lx, Ly, Nx, Ny)
% fdm=init(Lx, Ly, Nx, Ny)
% initialisation de la structure de donnees
    fdm.Nx=Nx;
    fdm.Ny=Ny;
    fdm.N =Nx*Ny;
    fdm.Lx=Lx;
    fdm.Ly=Ly;
    fdm.dx=Lx/(Nx-1);
    fdm.dy=Ly/(Ny-1);
end