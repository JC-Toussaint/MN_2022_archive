function fdm=solve(fdm, nmode)
% fdm=solve(fdm, nmode)
% calcul du mode numero nmode

fdm = dirichlet(fdm);
K = build_K(fdm);

N=fdm.N;
ld=fdm.ld;

Id=speye(N ,N);

size(Id)
P=Id;
P(ld, :)=[];

%RESOLUTION DE L'EQUATION AUX VALEURS PROPRES
% DEBUT BLOC A RECOPIER DANS VOTRE COPIE
% A COMPLETER
% FIN BLOC A RECOPIER DANS VOTRE COPIE

[Vp, D] = eigs(Kp, nmode, 'sm');
% vecteur propre associee valeur propre numero n

%RESOLUTION DE L'EQUATION AUX VALEURS PROPRES
% DEBUT BLOC A RECOPIER DANS VOTRE COPIE
% A COMPLETER
% FIN BLOC A RECOPIER DANS VOTRE COPIE

fdm.sol=sol;
end