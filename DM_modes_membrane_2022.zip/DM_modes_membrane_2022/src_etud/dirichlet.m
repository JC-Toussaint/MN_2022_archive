function fdm = dirichlet(fdm)
%fdm = dirichlet(fdm)
% Construction de la liste ld des noeuds de dirichlet
ld = []; 
% DEBUT BLOC A RECOPIER DANS VOTRE COPIE
% A COMPLETER
% FIN BLOC A RECOPIER DANS VOTRE COPIE

fdm.ld=unique(ld);
end

