function draw(fdm)
Nx=fdm.Nx;
Ny=fdm.Ny;
[X,Y] = meshgrid([0:Nx-1]*fdm.dx, [0:Ny-1]*fdm.dy);
for i=1:Nx
    for j=1:Ny
        n=index(i, j);
        Z(j, i)=fdm.sol(n);
    end
end

figure(1)
colormap jet
shading interp
surfc(X, Y, Z,'FaceColor', 'interp', 'EdgeColor','none','LineStyle','none','FaceLighting','phong');
colorbar
figure(2)
colormap jet
contour(X, Y, Z, 11);
colorbar
end