function n=index(ix, iy)
global Nx
n=(iy-1)*Nx+ix;
end