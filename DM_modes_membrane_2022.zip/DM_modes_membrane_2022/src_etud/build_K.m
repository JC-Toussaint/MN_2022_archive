function K=build_K(fdm)
% K=build_K(fdm)
% Construction de la matrice K
Nx=fdm.Nx;
Ny=fdm.Ny;
N =fdm.N;
dx=fdm.dx;
dy=fdm.dy;
ld=fdm.ld;

K=sparse(N, N);

for ix=1:Nx
    for iy=1:Ny
    n=index(ix, iy);   
    
% DEBUT BLOC A RECOPIER DANS VOTRE COPIE
% A COMPLETER
% FIN BLOC A RECOPIER DANS VOTRE COPIE 

    end
end
end