%FD_helm_main
% programme principal
clc
clear all
close all

global Nx
global Ny

Lx=1; Ly=1;
Nx=21; Ny=21; 
fdm=init(Lx, Ly, Nx, Ny);

nmode=1;
fdm=solve(fdm, nmode);
draw(fdm)
