%RESOLUTION DE L'EQUATION AUX VALEURS PROPRES
nmode=4;
[Vp, D] = eigs(Kp, nmode, 'sm');
% vecteur propre associee valeur propre numero n
up = Vp(:,nmode); 
