%RESOLUTION DE L'EQUATION AUX VALEURS PROPRES
n=4;
[V, D] = eigs(Kp, n, 'sm');
% vecteur propre associee valeur propre numero n
up = V(:,1);  
lp = D(1);
