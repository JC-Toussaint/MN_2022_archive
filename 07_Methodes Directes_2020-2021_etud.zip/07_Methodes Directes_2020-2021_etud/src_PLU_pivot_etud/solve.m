function x = solve(P, L, U, b)

% Resolution d'un systeme lineaire suite a la factorisation LU de sa matrice
% par Descente-Remontee
%
% ENTREE
%   L : Matrice triangulaire inferieure (sortie de falusp)
%   U : Matrice triangulaire superieure (sortie de falusp)
%   b    : second membre du systeme
%
% SORTIE
%   x : solution du systeme
%
% APPEL
%   x=solve(P, L,U, b) : renvoit dans x la solution de Ax=b ou
%   P est une matrice de permutation et L,U sont les
%   matrices triangulaires inf et sup de la matrice A
%

n = size(L,1) ;

% A COMPLETER
b=

%
% Resolution par descente remontee LUx=b
%
% Descente Ly=b
 
% A COMPLETER

% Remontee Ux=y

% A COMPLETER


