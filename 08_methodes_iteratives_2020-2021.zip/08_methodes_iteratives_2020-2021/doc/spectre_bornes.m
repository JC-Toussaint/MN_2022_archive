clc
clear all

% random avec la meme graine
rand ('seed',12563);
%randn('seed',12563);

N=1000;
A=rand(N, N);
A=A+A';

[V, D]=eig(A);
lb=diag(D);
for i=1:N
    [M, idx]=max(abs(V(:, i)));
    sum1=A(idx, idx);
    for j=1:N
        if (j==idx) continue; end
        sum1=sum1-abs(A(idx, j));
    end
    
    sum2=A(idx, idx);
    for j=1:N
        if (j==idx) continue; end
        sum2=sum2+abs(A(idx, j));
    end
    [sum1 lb(i) sum2]
    assert(sum1<=lb(i));
    assert(sum2>=lb(i));
end
