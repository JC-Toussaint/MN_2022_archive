function [x,flag,relres,iter,resvec] = bicgstab0(A,b,tol,maxit)

% Check for all zero right hand side vector => all zero solution
n2b = norm(b);                     % Norm of rhs vector, b
n=size(b, 1);
x = zeros(n,1);

% Set up for the method
flag = 1;
xmin = x;                          % Iterate which has minimal residual so far
tolb = tol * n2b;                  % Relative tolerance
r = b - A*x;
normr = norm(r);                   % Norm of residual
normr_act = normr;

rtilde = r;                            % Shadow residual
normrmin = normr;                  % Norm of residual from xmin
rho1 = 1;
alpha = 0;
omega = 1;

% loop over maxit iterations (unless convergence or failure)
for i = 1 : maxit
    rho2 = rho1;
    rho1 = dot(rtilde, r);
    if  i == 1
        p = r;
    else
        beta = (rho1/rho2)*(alpha/omega);
        p = r + beta * (p - omega * v);
    end

    phat = p;
    v = A*phat;
    alpha = rho1 / dot(rtilde, v);
    
    xhalf = x + alpha * phat;        % form the "half" iterate  
    s = r - alpha * v;             % residual associated with xhalf
    
    normr = norm(s);
    normr_act = normr;
    
    % check for convergence
    if (normr <= tolb)
        s = b - A*xhalf;
        normr_act = norm(s);
        if normr_act <= tolb
            x = xhalf;
            flag = 0;
            iter = i;
            break
        end
    end
    
    if normr_act < normrmin        % update minimal norm quantities
        normrmin = normr_act;
        xmin = xhalf;
    end
    
    shat = s;
    t = A*shat;
    tt = t' * t;
    omega = (t' * s) / tt;
        
    x = xhalf + omega * shat;        % x = (x + alpha * phat) + omega * shat
    r = s - omega * t;
    normr = norm(r);
    normr_act = normr;
    
    if normr_act < normrmin        % update minimal norm quantities
        normrmin = normr_act;
        xmin = x;
    end
    
end                                % for ii = 1 : maxit

% returned solution is first with minimal residual
if flag == 0
    relres = normr_act / n2b;
end

% only display a message if the output flag is not used
if nargout < 2
    disp(['bicgstab ' num2str(flag) ' ' num2str(tol) ' ' num2str(iter) ' ' num2str(relres)]);
end
