% random avec la meme graine
rand ('seed',12563);

% taille du systeme
N=400;  

% liste d'entiers unique 1..N r?partis aleatoirement
l=randperm(N);

tab_condA=[];
tab_iter=[];

for loop=0:100
lbmax=2^loop;
lb=linspace(1, lbmax, N);
tab_condA=[tab_condA lbmax];

A=sparse(diag(lb(l)));
 
disp (['condionnement de A '  num2str(lbmax)]);
 
% construction de b
b=rand(N, 1);
 
% point de depart x0
x=rand(N, 1);
 
% on efface les tableaux
clear xn en;
 
% tolerance
tol=1e-6;
 
% initialisation 
r=b-A*x;  
p=r;
rho1=r'*r;

n=1;
xn(:, n)=x;
en(n)=0.5*x'*A*x-x'*b;

% processus de minimisation
while (norm(r)/norm(b) > tol)
    alpha=rho1/(p'*A*p);
    x=x+alpha*p;
    r=b-A*x;
    rho=r'*r;   
    beta=rho/rho1;
    p=r+beta*p;
    rho1=rho;   
     
    n=n+1;
    xn(:, n)=x;
    en(n)=0.5*x'*A*x-x'*b;    
end;  
   
disp (['nombre d''iterations : '  num2str(n-1)]);
tab_iter=[tab_iter n-1];

% trace en echelle log10
ef=en(end); % valeur finale
semilogy(abs(en-ef));
grid on

end;

loglog(tab_condA, tab_iter);

