% interpol_lag1_3pts
clc
clear all
close all

xi=[1     2.7  3.2]
yi=[14.2 17.8 22.0]
N=length(xi);

% sur-echantillonnage pour le trace
x=min(xi):0.01:max(xi);
NP=length(x);
y=zeros(NP,1);

for np=1:NP
    y(np)=0;
    L=lag(xi, x(np));
    for i=1:N
        y(np)=y(np)+L(i)*yi(i);
    end
end

figure1 = figure('Color',[1 1 1]);

% Create axes
axes('Parent',figure1,'FontSize',14);
box('on');
grid('on');
hold('all');

% Create plot
plot(xi,yi,'MarkerSize',10,'Marker','o','LineWidth',2,'Color',[1 0 0]);

% Create plot
plot(x,y,'LineWidth',2,'Color',[0 0 1]);

% Create plot
figure2 = figure('Color',[1 1 1]);

% Create axes
axes('Parent',figure2,'FontSize',14);
box('on');
grid('on');
hold('all');

for np=1:NP
    L=lag(xi, x(np));
    y1(np)=L(1);
    y2(np)=L(2);
    y3(np)=L(3);
end

plot(x,y1,'LineWidth',2,'Color',[1 0 0]);
plot(x,y2,'LineWidth',2,'Color',[0 1 0]);
plot(x,y3,'LineWidth',2,'Color',[0 0 1]);
