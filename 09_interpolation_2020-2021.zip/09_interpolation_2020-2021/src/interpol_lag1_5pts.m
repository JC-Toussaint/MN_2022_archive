% interpol_lag1_5pts
clc
clear all
close all

xi=[1 2.7 3.2 4.8 5.6]
yi=[14.2 17.8 22 38.3 51.7]
N=length(xi);

% sur-echantillonnage pour le trace
x=min(xi):0.01:max(xi);
NP=length(x);
y=zeros(NP,1);

for np=1:NP
    y(np)=0;
    L=lag(xi, x(np));
    for i=1:N
        y(np)=y(np)+L(i)*yi(i);
    end
end

figure1 = figure('Color',[1 1 1]);

% Create axes
axes('Parent',figure1,'FontSize',14);
box('on');
grid('on');
hold('all');

% Create plot
plot(xi,yi,'MarkerSize',10,'Marker','o','LineWidth',2,'Color',[1 0 0]);

% Create plot
plot(x,y,'LineWidth',2,'Color',[0 0 1]);
