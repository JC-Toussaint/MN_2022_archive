function L=lag(xi, x)
% polynomes de lagrange evalues en x
% ENTREE
% xi vecteur de dim N
% x  abscisse scalaire
% SORTIE
% L vecteur de dim N : valeurs des Li(x)

N=length(xi);
for i=1:N % boucle sur tous les noeuds d'interpolation xi
    L(i)=1;
    for j=1:N
        if j~=i  % j different de i
           L(i)=L(i)*(x-xi(j))/(xi(i)-xi(j));
        end
    end
end

end