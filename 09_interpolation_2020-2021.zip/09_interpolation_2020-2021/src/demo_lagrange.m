function [x,y] = demo_lagrange(f,xinf, xsup, n, b)

% ENTREES  
%  f    : la fonction testee. Fonction preprogrammee comme log, erfc,sin
%         ou fonction utilisateur
%  xinf : borne inferieure de l'intervalle
%  xsup : borne superieure de l'intervalle
%  n    : nombre de points d'interpolation
%  b    : pourcentage de bruit
%
% APPEL
% demo_lagrange(f, xinf, xsup, n, b)
% exemple : demo_lagrange('sin', 0, 2*pi, 5, 0.05)

clc
close all

% evaluation aux points de mesure equi-repartis 
h = (xsup - xinf)/(n-1) ; 
xi = xinf:h:xsup ;
yi = feval(f,xi); 

% ajout d'un bruit blanc
yi = yi + b*(rand(1, n)-0.5);

% evaluation des polynomes de lagrange
% aux NP abscisses pour le trace
NP=100;
h = (max(xi) - min(xi))/(NP-1) ; 
x=min(xi):h:max(xi);

y=zeros(NP,1);
for np=1:NP % boucle sur les abscisses 
    ypol(np)=0;
    L=lag(xi, x(np));
    for i=1:n % boucle sur les noeuds d'interpolation
        y(np)=y(np)+L(i)*yi(i);
    end
end

% Visualisation
% Create figure
figure1 = figure('PaperSize',[20.98 29.68],'Color',[1 1 1]);

% Create axes
axes1 = axes('Parent',figure1,'FontSize',14);
box('on');
grid('on');
hold('all');

plot(x, feval(f,x), 'k', xi, yi,'o',x, y,'-r', 'LineWidth',2)
legend('Courbe theorique','Points de mesure','Courbe interpolee')
grid on

figure

% NP nb de points d'evaluation dans x in [xmin, xmax]
% n  nb de noeuds utilisés pour l'interpolation
y=zeros(n, NP); % n polynomes de lagrange
for np=1:NP
    L=lag(xi, x(np));
    for i=1:n
        y(i, np)=L(i);
    end
end

for i=1:n
    plot(x, y(i, :));
    hold on
end


