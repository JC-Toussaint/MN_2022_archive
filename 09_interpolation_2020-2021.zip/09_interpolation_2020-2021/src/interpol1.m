function interpol1
close all;
xi=[1 2.7 3.2 4.8 5.6]
yi=[14.2 17.8 22 38.3 51.7]

N=length(xi);
for i=1:N
    for j=1:N
        deg=j-1;
        A(i,j)=xi(i)^deg;
    end
end

a=A\yi';

hold on
x=min(xi):0.01:max(xi);
y=Pn(a, x);
plot(x,y, 'b')

figure1 = figure('Color',[1 1 1]);

% Create axes
axes('Parent',figure1,'FontSize',14);
box('on');
grid('on');
hold('all');

% Create plot
plot(xi,yi,'LineWidth',2, 'LineStyle','none','MarkerSize',10,'Marker','o','Color',[1 0 0]);

% Create plot
plot(x,y,'LineWidth',2,'Color',[0 0 1]);

function p=Pn(a, x)
for i=1:length(x)
    p(i)=0;
    for j=1:length(a)
    deg=j-1;
    p(i)=p(i)+a(j)*x(i)^deg;
    end
end
