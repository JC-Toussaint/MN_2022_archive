function Q=source(x)
Q=0;
% if x>=0.2 & x<=0.4
%    Q=5e7;
% else
%    Q=0;
% end