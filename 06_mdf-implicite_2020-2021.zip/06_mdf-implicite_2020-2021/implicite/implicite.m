function [x,Tn]=implicite(phys,simul);

% Programme de resolution d EDP 
% par la mehode des differences finis
% implicite transitoire

%   phys  : contient les caract�ristiques physiques du domaine,
%           propri�t�s physiques et conditions aux limites
%
%   simul : contient la description de la g�om�trie, les caract�ristiques
%           temporelles , la temp�rature initiale et la vitesse
%

%changement de variable pour plus de lisibilite
longueur=simul.longueur;
deltax=simul.deltax;
deltat=simul.deltat;
tfinal=simul.tfinal;

N=round(longueur/deltax+1);

% Initialisation t=0
Tprec=zeros(N,1);
Tprec(:)=simul.Tinit;

% declaration du systeme creux
A =sparse(N,N); % matrice du 1er membre
b =zeros(N,1);  % vecteur du 2nd membre

T=zeros(N,1);
x=[0:N-1]*deltax;

% nombre de pas de temps
nt=round(tfinal/deltat+1);
Tn=zeros(N,nt);

% Boucle sur le temps
inc=1;

%changement de variable pour plus de lisibilite
kth = phys.kth; % conductivite thermique
rho = phys.rho; % masse volumique
cp = phys.cp;   % capacite calorifique
vitesse = simul.vitesse % vitesse de deplacement

for t=0:deltat:tfinal
   
	% Initialisation : CAL a gauche
	if phys.type_cl_gauche=='DIRICHLET'		
        % CAL de Dirichlet
        x(1)=0;
		A(1, 1)=1;
		b(1)=phys.Tdg;
    else
        % CAL de Neumann
        hg=phys.hg;
        Tag=phys.Tag;  

        x(1)=0;
		A(1, 1)=2*kth/(deltax^2)+2*hg/deltax+rho*cp/deltat;
		A(1, 2)=-2*kth/(deltax^2);

   	    b(1)=Tag*(2*hg/deltax)+source(x(1))+rho*cp*Tprec(1)/deltat;
	end

	% Points interieurs du maillage
	for p=2:N-1
        % schema centre
        x(p)=(p-1)*deltax;
        A(p, p-1)=-kth/(deltax^2)-rho*cp*vitesse/(2*deltax);
        A(p, p  )=2*kth/(deltax^2)+rho*cp/deltat;
        A(p, p+1)=-kth/(deltax^2)+rho*cp*vitesse/(2*deltax);

		b(p)=source(x(p))+rho*cp*Tprec(p)/deltat;
	end

	% Initialisation : CAL a droite
	if phys.type_cl_droite=='DIRICHLET'  
        % CAL de Dirichlet
   	    x(N)=(N-1)*deltax;
		A(N, N)=1;
        
   	    b(N)=phys.Tdd;
    else
        % CAL de Neumann
        hd=phys.hd;
        Tad=phys.Tad;
        x(N)=(N-1)*deltax;
        
		A(N, N-1)=-2*kth/(deltax^2);
		A(N, N  )=2*kth/(deltax^2)+2*hd/deltax+rho*cp/deltat;
        
   	    b(N)=Tad*2*hd/deltax+source(x(N))+rho*cp*Tprec(N)/deltat;
	end

	%Resolution du systeme [A][y]=[b]

	T=A\b;
	% stockage des differents pas de temps
	Tprec(:)=T(:);
    Tn(:,inc)=T(:);
	inc=inc+1;
end

