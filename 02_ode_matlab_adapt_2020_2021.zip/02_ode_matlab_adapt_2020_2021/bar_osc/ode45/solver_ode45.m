% solver_ode45
close all
clc

% parametres
L=10;
m=1;
M=10.
g=9.81;

% stockage dans la structure
param.L=L;
param.m=m;
param.M=M;
param.g=g;

% duree & conditions initiales
tf=20;
x0=0; v0=0; theta0=pi/2; omega0=0;
dt=1e-2;
%opts = odeset('abstol',1e-6, 'MaxOrder', 2,'initialstep',dt, 'maxstep',dt,'stats','off');
opts = odeset('abstol',1e-6, 'MaxOrder', 4,'maxstep',dt,'stats','on');

[T,Y] = ode45(@barosc_ode45,[0 tf],[x0, v0, theta0, omega0], opts, param);

x    =Y(:,1);
v    =Y(:,2);
theta=Y(:,3);
omega=Y(:,4);

x    =Y(:, 1);
v    =Y(:, 2);
theta=Y(:, 3);
omega=Y(:, 4);

plot(T, x ,'r-')
hold on
plot(T, v, 'b-')
plot(T, theta, 'g-')
plot(T, omega, 'm-')
grid on


eta=m/(m+M);
c=v+eta*L*cos(theta).*omega;

figure
plot(T,c,'b-')
title('qte de mvt generalise');

Ep = -m*g*L*cos(theta);
Ec=0.5*(M+m)*v.^2+0.5*m*(L^2*omega.^2+2*L*cos(theta).*v.*omega);
Em=Ec+Ep;
figure
plot(T,Em, 'k-');
hold on
plot(T,Ec, 'r-');
plot(T,Ep, 'b-');
title('energie');

%save 'mydata.mat'

