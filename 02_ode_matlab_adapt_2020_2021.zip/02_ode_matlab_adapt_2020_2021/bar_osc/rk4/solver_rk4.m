clc
clear all
close all


global g m M L
g=9.8;  m=0.1; M=1.0; L=1.0; 

t0=0; tf=20; h=0.05
param=[t0 tf h];

x0=0; v0=0; theta0=pi/2; omega0=0;
[T,Y] = rk4(@barosc, param, [x0 v0 theta0 omega0]);

x    =Y(:, 1);
v    =Y(:, 2);
theta=Y(:, 3);
omega=Y(:, 4);

plot(T, x ,'r-')
hold on
plot(T, v, 'b-')
plot(T, theta, 'g-')
plot(T, omega, 'm-')
grid on

title('Methode RKm')

% figure
% h=T(2:end)-T(1:end-1);
% plot(T(1:end-1), h, 'r');
% grid on

figure

eta=m/(m+M);
c=v+eta*L*cos(theta).*omega;

plot(T,c,'b-')
title('qte de mvt generalise');

Ep = -m*g*L*cos(theta);
Ec=0.5*(M+m)*v.^2+0.5*m*(L^2*omega.^2+2*L*cos(theta).*v.*omega);
Em=Ec+Ep;
figure
plot(T,Em, 'k-');
hold on
plot(T,Ec, 'r-');
plot(T,Ep, 'b-');
title('energie');





