function dY_dt = barosc(t, Y)
dY_dt = zeros(1, 4);    % a row vector

global g m M L

% changement de variable 
% pour garder les notations de l'equation
x    =Y(1);
v    =Y(2);
theta=Y(3);
omega=Y(4);

% definition de la jacobienne
J = [M+m            m*L*cos(theta);
     m*L*cos(theta) m*L^2         ];
 
% definition de b
b=[ m*L*sin(theta)*omega^2;
   -m*g*L*sin(theta)      ];

sol = J\b;

dv_dt = sol(1);  domega_dt = sol(2);

% plus classiquement
dx_dt     = v;
dtheta_dt = omega;

% changement de variable pour 
% se conformer au vecteur de sortie dY_dt
dY_dt(1)=dx_dt;
dY_dt(2)=dv_dt;
dY_dt(3)=dtheta_dt;
dY_dt(4)=domega_dt;
end




