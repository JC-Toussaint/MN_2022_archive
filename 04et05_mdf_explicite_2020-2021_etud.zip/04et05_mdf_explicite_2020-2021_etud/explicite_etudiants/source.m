function Q=source(x)

if x>=0.1 & x<=0.15
    %Q=4000;
    Q=0;
else
    Q=0;
end

% Q=0;