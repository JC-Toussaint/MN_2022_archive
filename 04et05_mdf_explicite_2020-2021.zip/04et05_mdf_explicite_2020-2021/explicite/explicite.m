function [x,Tn]=explicite(phys,simul)
%
%    Programme de resolution d EDP par la methode des differences finies
%    explicite transitoire
%    
%    Entrees :
%    phys  : contient les caracteristiques physiques du domaine,
%            proprietes physiques et conditions aux limites
%
%    simul : contient la description de la geometrie, les caracteristiques
%            temporelles , la temperature initiale et la vitesse
%
%    Sorties :
%    x       : abscisses des points d'echantillonnage
%    Tn       : valeurs de l'inconnue en chaque point et a chaque instant
% 
%    Variables intermediaires
%    Tprec   :  valeurs de l'inconnue en chaque point et a l instant t-dt
%    T       :  valeurs de l'inconnue en chaque point et a l instant t

% parametres materiaux
kth = phys.kth;
rho = phys.rho;
cp  = phys.cp;

% parametres simuls
longueur = simul.longueur;
deltax   = simul.deltax;
deltat   = simul.deltat;
tfinal   = simul.tfinal;

% Nombre total de noeuds
NP=round(longueur/deltax+1);

% allocations et initialisations a zero
Tprec = zeros(NP,1);
T     = zeros(NP,1);
x     = zeros(NP,1);

x=[0:NP-1]*deltax;

Tprec(:)=simul.Tinit;

%sauvegarde du vecteur colonne Tprec(:) 
%dans la 1ere colonne de la matrice Tn
Tn=Tprec(:);

% Boucle sur le temps
t=0;
while t<tfinal
   
	% Initialisation : CAL a gauche
	if phys.type_cl_gauche=='DIRICHLET'		
        % CAL de Dirichlet
        Tdg = phys.Tdg;
     	x(1) =0;
     	T(1)=Tdg;
	else				
        % CAL de Neumann a gauche
        hg  = phys.hg;
        Tag = phys.Tag;  
        
        x(1)=0;
        dT_dx=(hg/kth)*(Tprec(1)-Tag);
        d2T_dx2=(Tprec(2)-Tprec(1)-deltax*dT_dx)*2./(deltax^2);
        conduction=-kth*d2T_dx2;  
        
        T(1)=Tprec(1)+(deltat/(rho*cp))*(source(x(1))-conduction);
   end

   % Points interieurs du maillage
   for p=2:NP-1
       x(p)=(p-1)*deltax;

       d2T_dx2=(Tprec(p+1)-2.*Tprec(p)+Tprec(p-1))/(deltax^2);
       conduction=-kth*d2T_dx2;
       T(p)=Tprec(p)+(deltat/(rho*cp))*(source(x(p))-conduction);          

   end

	% Initialisation : CAL a droite
	if phys.type_cl_droite=='DIRICHLET'  
        % CAL de Dirichlet
        Tdd = phys.Tdd;
        x(NP)=(NP-1)*deltax;
        T(NP)=Tdd;
    else
        % CAL de Neumann a droite
        hd  = phys.hd;
        Tad = phys.Tad;        

        x(NP)=(NP-1)*deltax;
        dT_dx=(-hd/kth)*(Tprec(N)-Tad);
        d2T_dx2=(Tprec(N-1)-Tprec(N)+deltax*dT_dx)*2/(simul.deltax^2);      
        conduction=-kth*d2T_dx2;       
        
        T(NP)=Tprec(NP)+deltat/(rho*cp)*(source(x(NP))-conduction);          
    end

	% stockage des differents pas de temps
    t=t+deltat;
    Tprec(:) = T(:); % (:) notation pas necessaire
    Tn = [Tn T(:)];  % ajout a droite du vecteur colonne T
end

