% ATTENTION NE PAS FAIRE
% ETUDE ANALYTIQUE UNIQUEMENT

function stab

rho=2700;
cp=897;
kth=237;
v=0.1;

dx=0.5;
dt=0.01;

a=2*kth/(rho*cp)*dt/(dx*dx);
b=v*dt/dx;

teta=0:1e-2:2*pi; 

x=(1.0-a*(1.0-cos(teta)));
y=(b*sin(teta));
G=abs(x+y*1i);

polar(teta, G);
format long;
max(G);
