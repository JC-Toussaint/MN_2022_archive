% flux a travers toutes les parois
function [qn]= flux(fem)  

%initialisation obligatoire du flux qn
qn =0;

NE=fem.NE;
for ne=1:NE
    e=fem.elt(ne);
    NBN=e.NBN;
    
    switch (e.TYP)
       case 1 % cas lineique
        % chargement des polynomes de Lagrange pour segment a 2 noeuds 
        [gauss]=polynomes_S2(fem, ne);
        nrg=e.NRG; %numero de region de l'element
        hcv=fem.equ.hcv(nrg);
        Ta =fem.equ.Ta (nrg);

        NPI=gauss.NPI;
        pds=gauss.pds;
        detJ=gauss.detJ;

        for npi=1:NPI 
            % calcul de la temperature au point de Gauss npi
            % par interpolation
            T(npi)=0;
            for ie=1:NBN 
                alphai = gauss.alpha(ie, npi);
                % passage numerotation locale -> globale
                iglobal=e.ind(ie);
                T(npi)=T(npi)+alphai*fem.sol(iglobal);
            end; 
            % accumulation
            qn =qn + hcv*(T(npi)-Ta) * pds(npi) * detJ(npi);
        end;
    end;
end;            
