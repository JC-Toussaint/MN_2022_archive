#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <utility>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <list>
#include <stdexcept>

#include <boost/format.hpp>
#include <boost/tokenizer.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/cuthill_mckee_ordering.hpp>
#include <boost/graph/properties.hpp>
#include <boost/graph/bandwidth.hpp>

using namespace std;
using namespace boost;

struct Node {
    double x, y, z;
    };

typedef adjacency_list<vecS, vecS, undirectedS, 
   property<vertex_color_t, default_color_type,
     property<vertex_degree_t,int> > > Graph;
typedef graph_traits<Graph>::vertex_descriptor Vertex;
typedef graph_traits<Graph>::vertices_size_type size_type;

class BadConversion : public std::runtime_error {
 public:
   BadConversion(const std::string& s)
     : std::runtime_error(s)
     { }
 };

template <typename T> 
inline T str2num(const std::string& s)
 {
   std::istringstream iss(s);
   T x;
   if (!(iss >> x))
     throw BadConversion("convertToDouble(\"" + s + "\")");
   return x;
 }

void reverse_cmk(string nom, vector <int> &old2newlabel, vector <int> &new2oldlabel) {
property_map <Graph, vertex_index_t>::type index_map;
vector <size_type> perm;
vector <Vertex>    inv_perm;

typedef boost::tokenizer<boost::char_separator<char> > tokenizer;
boost::char_separator<char> sep("=;:| \"\t");

ifstream fin(nom.c_str());
if (!fin) {
   cerr << "Pb lecture fichier " << nom << endl;
   exit(1);
   }

std::string str;
for (;;) {
    getline(fin, str); // 1eme ligne
    if (str.empty()) {
       cout << endl;
       continue;
       }

    tokenizer tokens(str, sep);
    tokenizer::iterator tok_iter = tokens.begin();
    cout << str << endl;
//    cout << *tok_iter << endl;
    if (*tok_iter=="$Nodes") break; 
}

int NOD=0;
for (;;) {
    getline(fin, str);
    if (str.empty()) {
       cout << endl;
       continue;
       }
    tokenizer tokens(str, sep);
    tokenizer::iterator tok_iter = tokens.begin();
    advance(tok_iter, 0);
    NOD=str2num<int>(*tok_iter);
    cout << NOD << endl;
    break;
    }

Graph G(NOD);
perm.resize(NOD);
inv_perm.resize(NOD);
old2newlabel.resize(NOD);
new2oldlabel.resize(NOD);

vector<Node> coord(NOD);
for (;;) {
    getline(fin, str); // 1eme ligne
    if (str.empty()) {
       continue;
       }

    tokenizer tokens(str, sep);
    tokenizer::iterator tok_iter = tokens.begin();
    if (*tok_iter=="$EndNodes") {
       break; 
       }
    int i=str2num<int>(*tok_iter)-1; 
    advance(tok_iter, 1);
    coord[i].x=str2num<double>(*tok_iter);
    advance(tok_iter, 1);
    coord[i].y=str2num<double>(*tok_iter);
    advance(tok_iter, 1);
    coord[i].z=str2num<double>(*tok_iter);
}



for (;;) {
    getline(fin, str); // 1eme ligne
    if (str.empty()) {
       continue;
       }

    tokenizer tokens(str, sep);
    tokenizer::iterator tok_iter = tokens.begin();
    cout << str << endl;
    if (*tok_iter=="$Elements") break; 
}

int NE=0;
for (;;) {
    getline(fin, str);
    if (str.empty()) {
//       cout << endl;
       continue;
       }
    tokenizer tokens(str, sep);
    tokenizer::iterator tok_iter = tokens.begin();
    advance(tok_iter, 0);
    NE=str2num<int>(*tok_iter);
    cout << NE << endl;
    break;
    }

int ne, REG, ELEM, tags, reg, TYP;

for (;;){
    getline(fin, str); // 1eme ligne
    if (str.empty()) {
       continue;
       }

    tokenizer tokens(str, sep);
    tokenizer::iterator tok_iter = tokens.begin();
    if (*tok_iter=="$EndElements") {
       break; 
       } 

    ne =str2num<int>(*tok_iter);
    advance(tok_iter, 1);
    TYP=str2num<int>(*tok_iter);
    advance(tok_iter, 1);
    tags=str2num<int>(*tok_iter);
    advance(tok_iter, 1);
    reg=str2num<int>(*tok_iter);
    advance(tok_iter, tags);

    switch (TYP){
        case 1:{
            int NBN=2;
            int ind[NBN];

            ind[0]=str2num<int>(*tok_iter)-1;
            advance(tok_iter, 1);
            ind[1]=str2num<int>(*tok_iter)-1;

            for (int i=0; i<NBN; i++)
            for (int j=0; j<NBN; j++){
                int ori = ind[i];
                int ext = ind[j];
                if (ext > ori)
                    add_edge(ori, ext, G);}

            break;
	    }
        case 2:{
            int NBN=3;
            int ind[NBN];
	    
            ind[0]=str2num<int>(*tok_iter)-1;
            advance(tok_iter, 1);
            ind[1]=str2num<int>(*tok_iter)-1;
            advance(tok_iter, 1);
            ind[2]=str2num<int>(*tok_iter)-1;

            for (int i=0; i<NBN; i++)
            for (int j=0; j<NBN; j++){
                int ori = ind[i];
                int ext = ind[j];
                if (ext > ori)
                    add_edge(ori, ext, G);}

            break;
	    }
	case 15: break;
        default:
            exit(1);
	}
    }

index_map = get(vertex_index, G);

cout << endl;
cout << "Original Bandwidth: " << bandwidth(G) << endl;

// reverse cuthill_mckee_ordering
cuthill_mckee_ordering(G, inv_perm.rbegin(), get(vertex_color, G), make_degree_map(G));

for (size_type c = 0; c != inv_perm.size(); ++c)
    perm[index_map[inv_perm[c]]] = c;

cout << "Final Bandwidth: " 
     << bandwidth(G, make_iterator_property_map(&perm[0], index_map, perm[0]))
     << endl;

for (vector<Vertex>::const_iterator i=inv_perm.begin(); i!=inv_perm.end(); ++i){
    int oldlabel=inv_perm[index_map[*i]];
    int newlabel=index_map[*i];
    old2newlabel[oldlabel]=newlabel;
    new2oldlabel[newlabel]=oldlabel;	   
    }

for (;;){
    getline(fin, str); // 1eme ligne
    cout << str << endl;
    if (fin.eof()) break;
    }
fin.close();    
}

