#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <utility>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <list>
#include <stdexcept>

#include <boost/format.hpp>
#include <boost/tokenizer.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/cuthill_mckee_ordering.hpp>
#include <boost/graph/properties.hpp>
#include <boost/graph/bandwidth.hpp>

using namespace std;
using namespace boost;

struct Node {
    double x, y, z;
    };

class BadConversion : public std::runtime_error {
 public:
   BadConversion(const std::string& s)
     : std::runtime_error(s)
     { }
 };

template <typename T> 
inline T str2num(const std::string& s)
 {
   std::istringstream iss(s);
   T x;
   if (!(iss >> x))
     throw BadConversion("convertToDouble(\"" + s + "\")");
   return x;
 }

void update_labelling(string nom0, vector <int> &old2newlabel, vector <int> &new2oldlabel) {

typedef boost::tokenizer<boost::char_separator<char> > tokenizer;
boost::char_separator<char> sep("=;:| \"\t");

ifstream fin(nom0.c_str());
if (!fin) {
   cerr << "Pb lecture fichier " << nom0 << endl;
   exit(1);
   }

std::string nom="mesh.pro";
ofstream fout(nom.c_str());
if (!fout) {
   cerr << "Pb ecriture fichier " << endl;
   exit(1);
   }

std::string str;
for (;;) {
    getline(fin, str); // 1eme ligne
    if (str.empty()) {
       fout << endl;
       continue;
       }

    tokenizer tokens(str, sep);
    tokenizer::iterator tok_iter = tokens.begin();
    if (*tok_iter=="$Nodes") break; 
}

fout << "NOEUDS" << endl;
int NOD=0;
for (;;) {
    getline(fin, str);
    if (str.empty()) {
       continue;
       }
    tokenizer tokens(str, sep);
    tokenizer::iterator tok_iter = tokens.begin();
    advance(tok_iter, 0);
    NOD=str2num<int>(*tok_iter);
    fout << NOD << endl;
    break;
    }

vector<Node> coord(NOD);
for (;;) {
    getline(fin, str); // 1eme ligne
    if (str.empty()) {
       cout << endl;
       continue;
       }

    tokenizer tokens(str, sep);
    tokenizer::iterator tok_iter = tokens.begin();
    if (*tok_iter=="$EndNodes") {
       break; 
       }
    int i=str2num<int>(*tok_iter)-1;
    advance(tok_iter, 1);
    coord[i].x=str2num<double>(*tok_iter);
    advance(tok_iter, 1);
    coord[i].y=str2num<double>(*tok_iter);
    advance(tok_iter, 1);
    coord[i].z=str2num<double>(*tok_iter);

//    cout << boost::format("%d %.18g %.18g %.18g") % i % coord[i].x % coord[i].y % coord[i].z << endl;
//    cout << *tok_iter << endl;
}

for (int nod=1; nod<=NOD; nod++) {
    int i=new2oldlabel[nod-1];
    fout << boost::format("%d %.18g %.18g") % (nod) % coord[i].x % coord[i].y  << endl;
    }

fout << endl;
fout << "ELEMENTS_SURFACIQUES_&_LINEIQUES" << endl;

for (;;) {
    getline(fin, str); // 1eme ligne
    if (str.empty()) {
       continue;
       }

    tokenizer tokens(str, sep);
    tokenizer::iterator tok_iter = tokens.begin();
//    cout << str << endl;
//    cout << *tok_iter << endl;
    if (*tok_iter=="$Elements") {
       break;
       } 
}

int NE=0;
for (;;) {
    getline(fin, str);
    if (str.empty()) {
       cout << endl;
       continue;
       }
    tokenizer tokens(str, sep);
    tokenizer::iterator tok_iter = tokens.begin();
    advance(tok_iter, 0);
    NE=str2num<int>(*tok_iter);
    fout << NE << endl;
    break;
    }

int ne, ELEM, tags, reg, TYP;

int REG=0;
multimap<int, int> bnd;

for (;;){
    getline(fin, str); // 1eme ligne
    if (str.empty()) {
//       cout << endl;
       continue;
       }

    tokenizer tokens(str, sep);
    tokenizer::iterator tok_iter = tokens.begin();
    if (*tok_iter=="$EndElements") {
//       cout << *tok_iter << endl;
       break; 
       } 

    ne =str2num<int>(*tok_iter);
    advance(tok_iter, 1);
    TYP=str2num<int>(*tok_iter);
    advance(tok_iter, 1);
    tags=str2num<int>(*tok_iter);
    advance(tok_iter, 1);
    reg=str2num<int>(*tok_iter);
    advance(tok_iter, tags);

    int NBN=0;
    switch (TYP){
           case 1:{
		NBN=2;
		break;
		}
	   case 2:{
	   	NBN=3;
		break;
		}
           case 15:{
		NBN=1;
		TYP=0;
		break;
		}
	   default:{
	   	cerr << "unknown element type : " << TYP << endl;
		exit(1);
		}
	   }

    fout << boost::format("%d %d %d ") % TYP % NBN % reg;
    REG=(reg>REG? reg:REG);

    int ind[NBN];
    double x[NBN], y[NBN];
    for (int nbn=0; nbn<NBN; nbn++) {
    	int i=str2num<int>(*tok_iter)-1;
        x[nbn]=coord[i].x;
        y[nbn]=coord[i].y;
        i=old2newlabel[i]+1;;
        bnd.insert(pair<int, int>(reg, i));
        ind[nbn]=i;
        advance(tok_iter, 1);
	}

if (NBN==3) {
    double detJ=(x[1]-x[0])*(y[2]-y[0])-(x[2]-x[0])*(y[1]-y[0]);
    if (detJ<=0) {
/*
        cout << x[0] << "\t" << y[0] << endl;
        cout << x[1] << "\t" << y[1] << endl;
        cout << x[2] << "\t" << y[2] << endl;
*/

	cerr << "Region " << reg << "  Element " << ne << " mal oriente";
        int tmp=ind[2];
        ind[2]=ind[1]; ind[1]=tmp;
        cerr << "... corrige !"<<endl;
//	exit(1);
	}
    }

    for (int nbn=0; nbn<NBN; nbn++) {
        int i=ind[nbn];
        fout << boost::format("%d ") % i;
	}
    
    fout << endl;        
}

fout << endl;
fout << "AFFECTATION_PROPRIETES_PHYSIQUES" << endl;
fout << REG << endl;
for (reg=1; reg<=REG; reg++)
    fout << "#A COMPLETER# REGION : " << reg << endl;

fout << endl;    
fout << "CONDITIONS_DIRICHLET" << endl;
fout << 0 << endl;

/*
multimap<int, int>::iterator p;
for (reg=1; reg<=REG; reg++) {
    fout << endl;
    p = bnd.find(reg);
    do {
       fout << p->second << " " <<0 << endl;
       p++;
       } while (p != bnd.upper_bound(reg));
    }
*/

multimap<int, int>::iterator p;
for (reg=1; reg<=REG; reg++) {
    typedef map<int, int> mapType;
    mapType m;

    p = bnd.find(reg);
    do {
       m[p->second]=reg;
       p++;
       } while (p != bnd.upper_bound(reg));

    fout << endl;
    fout << "#LIGNE A SUPPRIMER# "<<  m.size() << " Noeuds dans la Region " <<  reg << endl;
    for(mapType::const_iterator it = m.begin(); it != m.end(); ++it)
       {
       //fout << it->first << " " << it->second <<endl;
       fout << it->first << " " << 0 <<endl;
       }

    }

fin.close();
fout.close();        
}

