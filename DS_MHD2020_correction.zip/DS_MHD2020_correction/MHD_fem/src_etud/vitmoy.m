function [vmoy]= vitmoy(fem)  

som =0;
surf=0;

%%% DEBUT DU BLOC A RECOPIER DANS VOTRE COPIE %%%   
%%% A COMPLETER %%%  
%%% FIN DU BLOC A RECOPIER DANS VOTRE COPIE %%%

end