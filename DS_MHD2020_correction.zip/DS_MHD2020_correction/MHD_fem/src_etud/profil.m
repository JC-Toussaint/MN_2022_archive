% profil de l'inconnue sur un segment de droite defini par
% ses deux extremites a partir de la solution stockee dans
% la structure fem
% [tabval, err]=profil(fem, Npts, xi, yi, xf, yf);

function [tabval, err]=profil(fem, Npts, xi, yi, xf, yf)

h=figure(4);
hold off;
set(h, 'Position',[550 50 500 400]);

if (Npts<=0)
   err=1;
   return;
end;

dx=(xf-xi)/(Npts-1);
dy=(yf-yi)/(Npts-1);
ds=sqrt(dx*dx+dy*dy);

%abscisse curviligne
s=[0:Npts-1]*ds;

    vis  =fem.equ.vis(1);
    sig  =fem.equ.sig(1);
    E0   =fem.equ.E0(1);
    B0   =fem.equ.B0(1);

    b=1e-2;
    gam=(sig*E0*B0)/vis;
    lambda=sqrt(sig*B0^2/vis);

for n=1:Npts
    x=xi+dx*(n-1);
    y=yi+dy*(n-1);
    
    [val,grad_val_x,grad_val_y, err]=pick(fem, x, y);
    if (err)
       texte=['pick erreur en ' num2str(x) ' ' num2str(y)];
       disp(texte);
       err=1;
    end;

    tabval(n)=val;
    tabgradx(n)=grad_val_x;
    tabgrady(n)=grad_val_y;
    
%%% DEBUT DU BLOC A RECOPIER DANS VOTRE COPIE %%%   
%%% A COMPLETER %%% 
 
    vit_anal(n)=E0/B0*(1-cosh(lambda*y)/cosh(lambda*b));
   
    vit_anal(n)=E0/B0*(1-besselj(0, 1i*lambda*y)/besselj(0, 1i*lambda*b));
    
%%% FIN DU BLOC A RECOPIER DANS VOTRE COPIE %%%   

end;

subplot(2,1,1)
plot(s,tabval,'b.');

hold on;
plot(s, vit_anal, 'r');
title ('v le long d un segment')
grid on
ylabel('v')
              
subplot(2,1,2)
plot(s,tabgrady,'b.');
title('dv/dy le long d un segment')
grid on
xlabel('abscisse curviligne')
ylabel('dv/dy')

