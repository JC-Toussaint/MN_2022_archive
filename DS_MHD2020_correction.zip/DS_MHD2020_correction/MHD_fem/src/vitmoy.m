function [vmoy]= vitmoy(fem)  

som =0;
surf=0;
NE=fem.NE;
for ne=1:NE
    e=fem.elt(ne);
	% polynomes de Lagrange associes a ses noeuds ainsi que leur gradient
	switch(e.TYP)
        case 1
		     % chargement des polynomes de Lagrange pour segment a 2 noeuds 
             [gauss]=polynomes_S2(fem, ne);
        case 2     
		     % chargement des polynomes de Lagrange pour triangle a 3 noeuds
             [gauss]=polynomes_T3(fem, ne);
  
             NPI=gauss.NPI;
             detJ=gauss.detJ;

             for npi=1:NPI 
                 NBN=e.NBN;
                 for ie=1:NBN 
                     alphai = gauss.alpha(ie, npi);

                     iglobal=e.ind(ie);
                     som =som +alphai*fem.sol(iglobal)*gauss.pds(npi)*detJ(npi);
                     surf=surf+alphai*gauss.pds(npi)*detJ(npi);
                 end;    
             end;
     end;
end;

vmoy=som/surf;