clc
syms r positive
syms lb positive
syms R positive
syms r

syms E0 B0

u=E0/B0*(1-besseli(0, lb*r)/besseli(0, lb*R))

res=int(u*2*pi*r, r, 0, R)/(pi*R^2)

simplify(res)

R=0.01
E0=1
B0=2
nu=1e-3
sig=10
lb=sig*B0^2/nu
E0/B0*(1-2*besseli(1, lb*R)/(lb*R*besseli(0, lb*R)))

((pi*E0*R^2)/B0 + (E0*pi*R*besselj(1, R*lb*i)*2*i)/(B0*lb*besselj(0, R*lb*i)))/(pi*R^2)