ld=unique(ld)
