% WGgen : generateur d'une grille reguliere de type 
% differences/volumes finis
% Auteurs JC Toussaint & L Bastard 

% dependance : fonction inpoly
% Auteur : Darren Engwirda
%

function g=WGgen
clc
clear all
close all

h=0.1;
g=uniform_grid(-5.0, 5.0, -3.0, 3.0, h, h);

% coordonnees des sommets du polygone
region = [
       -2  -1;
       +2  -1;
       +1  +1;
       -1  +1
       ];
 
g=insert(g, region);
end

