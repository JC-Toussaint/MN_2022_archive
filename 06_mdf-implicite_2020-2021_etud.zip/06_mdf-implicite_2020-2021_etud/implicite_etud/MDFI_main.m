% SEANCE 3 : METHODE DES DIFFERENCES FINIES - ORDRE 2 - IMPLICITE - LINEAIRE
%            UN SEUL DOMAINE D'ETUDE EN DIMENSION 1
%            EQUATION THERMIQUE TRANSITOIRE AVEC DIFFUSION, SOURCE ET 
%            NEUMANN OU DIRICHLET EN FRONTIERE
%
%  Le programme comporte 2 structures de donn�es :
%
%  La structure phys 
%  -----------------
%  Cette structure contient toutes les donn�es physiques du domaine d'�tude
%
%  phys.kth     : Conductivit� thermique du mat�riau
%  phys.rho     : Masse volumique du mat�riau
%  phys.cp      : Capacit� calorifique du mat�riau
%
%  phys.type_cl_gauche : Type de condition aux limites � gauche 
%                        (DIRICHLET ou NEUMAN)
%  phys.type_cl_droite : Type de condition aux limites � droite 
%                        (DIRICHLET ou NEUMAN)
%  phys.Tdg     : Temp�rature de DIRICHLET � gauche
%  phys.Tdd     : Temp�rature de DIRICHLET � droite
%  phys.Tag     : Temp�rature ambiante � gauche
%  phys.Tad     : Temp�rature ambiante � droite
%  phys.hg      : Coefficient d'�change convectif � gauche
%  phys.hd      : Coefficient d'�change convectif � droite
%
%  La structure simul
%  ------------------
%  Cette structure contient les caract�ristiques g�om�triques ainsi que 
%  les param�tres temporels de la simulation, la temp�rature initiale et
%  la vitesse si il y a lieu.
%  
%  simul.longueur : Longueur du barreau
%  simul.deltax   : Pas d'espace
%  simul.tfinal   : Dur�e totale de la simulation
%  simul.deltat   : Pas de temps
%  simul.Tinit    : Temp�rature initiale du barreau
%  simul.vitesse  : Vitesse du barreau
%
%
%  Noms des fonctions :
%  
%  MDFI_main            : Programme principal
%    lecture_probleme   : Lecture des proprietes physiques
%    lecture_simul      : Lecture des parametres de la simulation
%    implicite          : Algorithme de r�solution transitoire implicite
%      source           : Fonction permettant de calculer la source en un point
%                       d�fini par sa coordonn�e sur le barreau
%      tridiag          : Resolution du systeme tridiagonal
%    affichage_solution :
%      val_coul         : Fonction permettant d'associer une couleur en fonction
%                         d'un index de mani�re � colorier les courbes r�sultats 
%                         en fonction du temps.
%

%
%  PROPRIETES PHYSIQUES DU MATERIAU et CONDITIONS AUX LIMITES A GAUCHE
%
[phys]=lecture_probleme

%
%  PARAMETRES DE LA SIMULATION
%
% Parametres de la simulation et tests sur la stabilite
[simul]=lecture_simul(phys)
 
% methode implicite
[x,Tn]=implicite(phys,simul);

%
%  AFFICHAGE DU RESULTAT
%
% Representation graphique              
affichage_solution(x,Tn,simul)
