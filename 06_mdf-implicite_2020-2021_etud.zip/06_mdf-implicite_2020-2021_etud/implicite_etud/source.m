function Q=source(x)

if x>=0.2 & x<=0.4
   Q=5e7;
else
   Q=0;
end