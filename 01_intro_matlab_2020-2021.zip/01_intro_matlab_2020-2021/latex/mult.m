function [R]=mult(A, B)
%multiplication de deux matrices
%[R]=mult(A, B)

NcolA=size(A, 2);
NligB=size(B, 1);

if NcolA==NligB
   R=A*B;
else
   R=0;
   error('Erreur : dimensions non compatibles');
end;
end
