clc
clear all

A=rand(21, 41);
B=rand(41, 31);

tic % start timer
[M]=mult(A, B)     % version de base
toc % stop timer

tic
[M]=mult_advanced(A, B) % version avancee
toc