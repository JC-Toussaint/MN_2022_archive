clc         % clear command window
clear all   % clear variables
close all   % close all graphic windows

A=rand(1, 100);

tic % start timer
[A]=tri_rapide(A, 1, length(A))    
toc % stop timer

