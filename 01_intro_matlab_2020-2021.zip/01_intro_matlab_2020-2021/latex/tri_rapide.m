function [T]=tri_rapide(T, g, d)
%
% [T]=tri_rapide(T, 1, length(T))
%
if g<d
    [ip, T]=partition(T, g, d);
    T=tri_rapide(T, g, ip);
    T=tri_rapide(T, ip+1, d);
end;
end

function [j, T]=partition(T, g, d)
pivot=T(g);
i=g-1;
j=d+1;
while true
    cond=true; %----------------- repeat             
    while cond
        j=j-1;
        cond = (T(j)<=pivot); % -- until cond
        cond = ~cond;        % contraposee  
    end;       
    
    cond=true; %----------------- repeat     
    while cond
        i=i+1;
        cond = (T(i)>=pivot); % -- until cond
        cond = ~cond;        % contraposee   
    end;       

    if i<j
        tmp=T(i); T(i)=T(j); T(j)=tmp;
        bar(T, 'r'); % representation
        drawnow;     % graphique de T
        %pause(1)     
    else
        return;
    end;
end;
end






