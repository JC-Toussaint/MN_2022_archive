function y=fonction(x)
 
 %y=x^3-x^2-10*x+2;
 y=-x^3+x^2+5*x+2;