% exercie 6

a=1;
n=10;
x=resol(a,n)


a=5;
n=50;
x=resol(a,n)
