% exercice 4

x=-50:0.1:50;
y=x.*sin(x);
plot(x,y)
xlabel('x')
ylabel('y')
title('Fonction x*sin(x)')
