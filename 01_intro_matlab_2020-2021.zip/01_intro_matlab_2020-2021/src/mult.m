function [R]=mult(A, B)
try
  R=A*B;
catch err % capture de l'erreur
    error('dimensions non compatibles');
end;
end
