function [lambda, x, iter]=puissance_inverse_shift(A, x, shift)
% Methode de la puissance iteree
% [lambda, x]=puissance_inverse_shift(A, x)
% A matrice hermitique (nxn) et x vecteur de n colonnes

eps=1e-6;
iter=0;
[nlig, ncol]=size(A);
if nlig ~= ncol
    error('matrice non carree');
end;

A=A-shift*eye(nlig);

cond=true;  %---------------------- repeat
while cond
    x0=x;
    v=A\x;  % on resoud Av=x a chaque iteration
    x=v/norm(v);
    iter=iter+1; 
    cond = (norm(x-x0) < eps) || (norm(x+x0) < eps); %--- until cond
    cond = ~cond;                                    % contraposee
end;        

lambda=x'*A*x;
lambda=lambda+shift;
end


