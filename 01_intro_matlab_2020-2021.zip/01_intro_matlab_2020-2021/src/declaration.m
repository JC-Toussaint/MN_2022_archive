% programme d utilisation de zeros, ones et diag
clear all

N=3;
t=ones(N,N)
t

N=2;
u=zeros(N,N);
u

N=3;
ones(N,1)
v=diag(ones(N,1))
