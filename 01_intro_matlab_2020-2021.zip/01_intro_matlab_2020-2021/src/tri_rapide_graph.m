function [T]=tri_rapide_graph(T, g, d, indent)
%
% [T]=tri_rapide(T, 1, length(T))
%
if g<d
    disp([indent ' ' num2str(g) ' ' num2str(d)])
    indent=[indent indent];
    [ip, T]=partition(T, g, d);
    T=tri_rapide_graph(T, g, ip, indent);
    T=tri_rapide_graph(T, ip+1, d, indent);
end;
end

function [j, T]=partition(T, g, d)
pivot=T(g);
i=g-1;
j=d+1;
while true
    cond=true; %----------------- repeat             
    while cond
        j=j-1;
        cond = (T(j)<=pivot); % -- until cond
        cond = ~cond;          
    end;       
    
    cond=true; %----------------- repeat     
    while cond
        i=i+1;
        cond = (T(i)>=pivot); % -- until cond
        cond = ~cond;         
    end;       

    if i<j
        tmp=T(i); T(i)=T(j); T(j)=tmp;
    else
        return;
    end;
end;
end


