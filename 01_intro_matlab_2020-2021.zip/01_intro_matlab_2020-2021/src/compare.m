% programme de comparaison
% utilisation de if else end

i=input('nombre i : ');
j=input('nombre j : ');

if (i<j)
    disp('i<j');
else
   disp('i>=j');
end
