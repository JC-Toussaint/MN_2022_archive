function tri_rapide_bench
clc
close all
N=20;
sz  =zeros(1, N);
time=zeros(1, N);
for n=1:N
    n
    sz(n)=2^n;
    T=rand(1, 2^n);
    tic;
    T=tri_rapide(T, 1, length(T));
    time(n)=toc;
end;
plot(sz, time./log(sz))
end


function [T]=tri_rapide(T, g, d)
if g<d
    [ip, T]=partition(T, g, d);
    T=tri_rapide(T, g, ip);
    T=tri_rapide(T, ip+1, d);
end;
end

function [j, T]=partition(T, g, d)
pivot=T(g);
i=g-1;
j=d+1;
while true
    cond=true;
    while cond
        j=j-1;
        cond = (T(j)>pivot);
    end;
    cond=true;
    while cond
        i=i+1;
        cond = (T(i)<pivot);
    end;

    if i<j
        tmp=T(i); T(i)=T(j); T(j)=tmp;
    else
        return;
    end;
end;
end


