function [lambda, x, iter]=puissance_inverse(A, x)
% Methode de la puissance iteree
% [lambda, x]=puissance_inverse(A, x)
% A matrice hermitique (nxn) et x vecteur de n colonnes

eps=1e-6;
iter=0;

cond=true;  %-------------------------------------------- repeat
while cond
    x0=x;
    v=A\x;  % on resoud Av=x a chaque iteration
    x=v/norm(v);
    iter=iter+1;
    cond = (norm(x-x0) < eps) || (norm(x+x0) < eps); %--- until cond
    cond = ~cond;                                    % contraposee
end;        

lambda=x'*A*x; % = conj(transpose(x)) * A * x;
end


