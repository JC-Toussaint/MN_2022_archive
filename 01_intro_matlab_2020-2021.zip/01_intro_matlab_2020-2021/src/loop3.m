% programme loop3

i=1;
while(true)
        disp(i);
        i=i+1;
        if(i>10)
            break;
        end
end
