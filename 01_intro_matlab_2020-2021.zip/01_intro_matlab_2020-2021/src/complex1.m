% programme complex1

x=input('argument en rad ');

disp(cos(x));
disp(sin(x));

disp(exp(1i*x));

