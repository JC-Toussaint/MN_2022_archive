% 1ere fonction avec matlab
% utilisation de la fonction disp
disp('Bonjour Phelma');
