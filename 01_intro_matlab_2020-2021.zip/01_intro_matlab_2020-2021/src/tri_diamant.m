% 
% algorithme de tri de valeurs DISTINCTES
% ATTENTION aucun doublon permis
%
% T=floor(1000*rand(1, 10))
% T=tri_diamant(T)
%
function [ T ] = tri_diamant(T)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

[Tg, Td]=partition(T);
if length(Tg)>1
   Tg=tri_v1(Tg);
end
if length(Td)>1
Td=tri_v1(Td);
end
T=[Tg Td];
end


function [Tg, Td]=partition(T)
ip=floor(length(T)*rand(1))+1;
Tg=[];
Td=[];
pivot=T(ip);

for i=1:length(T)
    if T(i)<pivot
        Tg=[Tg T(i)];
    else
        Td=[Td T(i)];
    end
end
end