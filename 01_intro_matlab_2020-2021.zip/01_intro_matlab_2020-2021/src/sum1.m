% programme sum1

N=10;
sum=0;

for i=1:N
    sum=sum+i;
end

disp(sum);
disp(N*(N+1)/2);
