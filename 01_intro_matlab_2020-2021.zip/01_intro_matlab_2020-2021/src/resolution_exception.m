% Resolution de systeme
function [X, err]=resolution_exception(A,b)

warning on verbose

try
    err=0;
    X=A\b;
    error(lastwarn);
catch ME
    ME
    err=1;
    X=0;
end;
end

