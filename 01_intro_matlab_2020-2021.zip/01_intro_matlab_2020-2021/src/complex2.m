% programme complex2

x=input('argument en rad ');

s=[num2str(cos (x)) ' +i *' ...
     num2str(sin (x)) ]

disp(s);

disp(exp(1i*x));

