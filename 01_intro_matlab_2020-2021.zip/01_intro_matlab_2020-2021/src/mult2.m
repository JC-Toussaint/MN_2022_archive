% multiplication de deux matrices A et B
% R = mult2(A, B)
% Contrainte size(A, 2) = size(B, 1) 

function [R]=mult2(A, B)

NLigA=size(A, 1); % Nb lignes   de A
NColA=size(A, 2); % Nb Colonnes de A

NLigB=size(B, 1);
NColB=size(B, 2);

if NColA ~= NLigB 
% incompatibilite entre le nombre de lignes de A
% et le nombre de colonnes --> stop
    error('dimensions non compatibles');
end;

R=zeros(NLigA, NColB);

for i=1:NLigA
    for j=1:NColB
        for k=1:NColA
        R(i,j) = R(i,j) + A(i, k)*B(k,j);
        end;
    end;
end;

end
