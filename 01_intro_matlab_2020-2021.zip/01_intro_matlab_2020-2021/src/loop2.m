% programme loop2

i=1;
while (i<=10)
    disp(i);
    i=i+1;
end
