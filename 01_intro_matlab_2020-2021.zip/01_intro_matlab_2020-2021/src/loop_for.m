for i=1:10
    N=i;
end

disp(N)

for i=1,10
    N=i;
end

disp(N)
