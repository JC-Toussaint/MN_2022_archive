function [lambda, x, iter]=puissance_v2(A, x)
% Methode de la puissance iteree
% [lambda, x]=puissance_v2(A, x)
% A matrice hermitique (nxn) et x vecteur de n colonnes

eps=1e-6;
eps=1e-15;
iter=0;

while true
    x0=x;
    v=A*x;
    x=v/norm(v);
    iter=iter+1;
    cond = (norm(x-x0) < eps) || (norm(x+x0) < eps); 
    if cond
        break;
    end
end;                

lambda=x'*A*x; % = conj(transpose(x)) * A * x;
end


