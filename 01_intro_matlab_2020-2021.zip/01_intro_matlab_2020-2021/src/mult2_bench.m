clc
clear all
close all

N=10;
sz   =zeros(1, N);
tcpu =zeros(1, N);
for n=1:N
    n
    s=2^n;
    sz(n)=s;
    A=rand(s, s);
    B=rand(s, s);
    tic
    R=mult2(A, B);
    tcpu(n)=toc;
end;

loglog(sz, tcpu, 'o');
hold on;

fit=sz.^3; % theorie
loglog(sz, fit, 'r-');
grid on;
