% puissance iteree de mat A hermitique de dim nxn
% [lambda, u]=puissance(A, x0)
% x0 vecteur colonne de dim n

function [lambda, u]=puissance(A, x0)
n = size(A, 1);	% nb de lignes
iter=0; 
itermax=100;  
epsilon=1e-6;

while (iter < itermax)
	u = A*x0;
	x = u / norm(u);
 	if (norm(x-x0) < epsilon)
     		disp(norm (x-x0));
     		break;
  	end
	x0=x;
	iter=iter+1;
end

u = x; % x de norme 1
lambda = u' * A *u;
disp(['nb iterations' num2str(iter)]);
end
